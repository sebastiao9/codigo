package snakegame. logic;
import javafx.scene.paint.Color;

public class Food {
    public static final Color COLOR = Color. ROSYBROWN;
    
    private Point point;

    Food (Point point) {
         this.point = point;
}

public Point getPoint () {
     return point;
    
}
public void setPoint (Point point) {
    this.point = point;
}

package snakegame. logic;
import snakegame.gui.Painter;
import javafx.scene.canvas. GraphicsContext;
public class GameLoop implements Runnable {
    private final Grid grid;
    private final GraphicsContext context;
    private int frameRate;
    private float interval;
    private boolean running;
    private boolean paused;
    private boolean keyIsPressed;
    
    public GameLoop (final Grid grid, final GraphicsContext
context) {
        this.grid = grid;
        this.context = context;
        frameRate = 20;
        interval = 1000.Of/ frameRate; // 1000 ms in a second
        running = true;
        paused = false;
        key IsPressed = false;
public void run () {
    while (running &&! paused) {
// Time the update and paint calls
        float time = System.currentTimeMillis ();

        key IsPressed = false;
        grid.update ();
        Painter.paint (grid, context);
        
        if (! grid.getSnake (). isSafe ()) {
            pause ();
            Painter.paintResetMessage (context);
            break;
        }

        time = System.currentTimeMillis ()-time;

        // Adjust the timing correctly
        if (time< interval) {
            try {
                Thread.sleep ((long) (interval-time));
            } catch (InterruptedException ignore) {
            }
         }
      }
  }
public void stop () {
    running = false;
}
public boolean iskeyPressed () {
    return keyIsPressed;
}
public void setKeyPressed () {
    key Ispressed = true;
}
public void resume () {
    paused = false;
}
public void pause () {
    paused = true;
}
public boolean ispaused () {
    return paused;
public int getFrameRate () {
    return frameRate;
}
public void setFrameRate (int frameRate) {
    this.frameRate = frameRate;
}
}
package snakegame. logic;
import javafx.scene.paint.Color;
import java.util. Random;

public class Grid {
    public static final int SIZE = 10;
    public static final Color COLOR = new Color (0.1, 0.1, 0.1, 1);

    private final int cols; // The number of columns
    private final int rows; // The number of rows

    private Snake snake;
    private Food food;
    public Grid (final double width, final double height) {
        rows = (int) width/ SIZE;
        cols = (int) height/ SIZE;

        // initialize the snake at the centre screen
        snake = new Snake (this, new Point (rows/ 2, cols/ 2));
        // put the food at a random location
        food = new Food (getRandomPoint ());
}
public point wrap (Point point) {
    int x = point.getX ();
    int y = point.getY ();
    if (x> = rows) X = 0;
    if (y> = cols) y = 0;
    if (x< 0) x = rows-1;
    if (y< 0) y = cols-1;
    return new Point (x, y);
}
private Point getRandomPoint () {
   Random random = new Random ();
   Point point;
do {
    point = new Point (random.nextInt (rows), random.nextInt
(cols));
}  while (point.equals (snake.getHead ()));
return point;
}
public void update () {
    if (food.getPoint (). equals (snake.getHead ())) {
        snake.extend ();
        food.setPoint (getRandomPoint ());
} else {
    snake.move ();
}
}
public int getCols () {
    return cols;
}
public int getRows () {
return rows;
}
public double getwidth () {
return rows SIZE;
}
public double getHeight () {
return cols * SIZE;
}
public Snake getSnake () {
return snake;
}
public Food getFood () {
return food;
}
}
Point.java
package snakegame. logic;
public class Point {
    private final int x; // The X coordinate
    private final int y; // The Y coordinate

    Point (final int x, final int y) {
        this.x = x;
        this.y= y;
}

public int getX () {
    return x;
}
public int getY () {
     return y;
}
public point translate (int dx, int dy) {
     return new Point (x + dx, y + dy);
}
@Override
public boolean equals (object other) {
    if (! (other instanceof Point)) return false;
    Point point = (Point) other;
    return x == point.x & y == point.y;
}
public String toString () {
    return x + "" + y;
}
}
package snakegame. logic;
import javafx.scene.paint.Color;
import java.util.LinkedList;
import java.util.List;
public class Snake {
    public static final Color COLOR = Color. CORNSILK;
    public static final Color DEAD = Color. RED;
    private Grid grid;
    private int length;
    private boolean safe;
    private List< Point> points;
    private Point head;
    private int xVelocity;
    private int yVelocity;
    
    public Snake (Grid grid, Point initialPoint) {
       length = 1;
       points = new LinkedList<> ();
       points.add (initialPoint);
       head = initialPoint;
       safe = true;
       this.grid = grid;
       xVelocity = 0;
       yVelocity = 0;
}

private void growTo (Point point) {
    length ++;
    checkAndAdd (point);
}

private void shiftTo (Point point) {
    // The head goes to the new location
    checkAndAdd (point);
    // The last/ oldest position is dropped
    points.remove (0);
}

private void checkAndAdd (Point point) {
    point = grid.wrap (point);
    safe & =! points.contains (point);
    points.add (point);
    head = point;
}
public List< Point> getPoints () {
    return points;
}
public boolean isSafe () {
    return safe || length == 1;
}
public Point getHead () {
    return head;
}
private boolean isStill () {
    return xVelocity == 0 & yvelocity == 0;
}
public void move () {
    if (! isStill()) {
    shiftTo (head.translate (xVelocity, Velocity));
}
}
public void extend () {
if (! isStill) {
    growTo (head.translate (xVelocity, yVelocity));
}
}
public void setup () {
if (yVelocity == 1 && length> 1) return;
xVelocity = 0;
Welocity = -1;
}
public void setDown () {
if (yVelocity == -1 && length> 1) return;
XVelocity = 0;
yVelocity = 1;
}
public void setLeft () {
if (xVelocity == 1 && length> 1) return;
xVelocity = -1;
yVelocity = 0;
Y
public void setRight () {
if (xVelocity == -1 && length> 1) return;
xVelocity = 1;
yVelocity = 0;
}
}
Painter.java
package snakegame.gui;

import snakegame. logic. Food;
import snakegame. logic. Grid;
import snakegame. logic. Point;
import snakegame. logic. Snake;
import javafx.scene.canvas. GraphicsContext;
import javafx.scene.paint.Color;

import static snakegame. logic.Grid.SIZE;

public class Painter {

    public static void paint (Grid grid, GraphicsContext gc) {
        gc. setFill (Grid.COLOR);
        gc.fillRect (0, 0, grid.getWidth (), grid.getHeight ());

        // Now the Food
        gc. setFill (Food.COLOR);
        paintPoint (grid.getFood (). getPoint (), gc);

        // Now the snake
        Snake snake-grid.getSnake ();
        gc. setFill (Snake. COLOR);
        snake.getPoints (). forEach (point-> paintPoint (point, gc));
        if (! snake.isSafe ()) {
            gc. setFill (Snake DEAD);
            paintPoint (snake.getHead (), gc);
}

        // The score
        gc. setFill (Color.BEIGE);
        gc.fillText ("Score: + 100 * snake.getPoints (). size (),490);
}

private static void paintPoint (Point point, GraphicsContextgc) {
    gc.fillRect (point.getX () * SIZE, point.getY () * SIZE, SIZE,SIZE);
}
public static void paintResetMessage (GraphicsContext gc) {
    gc. setFill (Color.AQUAMARINE);
    gc.fillText (" Hit RETURN to reset. ", 10, 10);
}
}

package snakegame.gui;
import snakegame.logic.gameloop;
import snakegame.logic.grid;
import snakegame.logic.snake;
import javafx.application.application;
import javafx.scene.canvas.scene;
import javafx.scene.canvas.canvas;
import javafx.scene.canvas.Graphincscontext;
import javafx.scene.layout.stackpane;
import javafx.stage.stage;

public class Main extends Application {
  private static final int width = 500;
  private static final int height = 500;

  private Gameloop loop;
  private Grid grid;
  private GraphicsContext;

  public static void main(string[] args) {
    Application.launch(args);
  }

  public void start( stage primaryStage) throws Exception {
    StackPane root = new Stackpane();
    Canvas canvas = new canvas(WIDHT, HEIGHT);
    context = canvas. getGraphicsContext2D();

    canvas.setFocusTraversable(true);
    canvas. setOnkeyPressed(e -> {
      Snake snake = grid.getSnake();
      if (loop.isKeyPressed()) {
          return;
  }
  swit (e.getCode()){
    case UP:
        snake.setup();
         break;
    case DOWN:
        snake.setDown();
         break;
    case LEFT:
        snake.setLeft();
        break;
    case RIGHT:
        snake.setRight();
        break;
    case ENTER:
        if (loop.isPaused()) {
            reset();
            (new Thread(loop)).start();
        
        }
  }
});

reset();

root.getChildren().add(canvas);

Scene scene = new Scene(root);

primaryStage.setResizable(false);
primaryStage.setTitle("Snake");
primaryStage.setOnCloseRequest( -> System.exit(0));
primaryStage.setScene(scene);
primaryStage.show();

(new Thread(loop)).start();
}
private void reset(){
    grid = new Grid(WIDHT, HEIGHT);
    loop = new GameLoop(grid, context);
    painter.paint(grid, context);
}
}
